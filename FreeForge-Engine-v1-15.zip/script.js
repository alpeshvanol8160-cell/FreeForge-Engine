import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const viewport = document.getElementById('viewport');
const hierarchy = document.getElementById('hierarchy');
const objectCount = document.getElementById('objectCount');
const statusMessage = document.getElementById('statusMessage');
const sceneStatus = document.getElementById('sceneStatus');
const inspector = document.getElementById('inspector');
const inspectorEmpty = document.getElementById('inspectorEmpty');
const fileInput = document.getElementById('fileInput');

const scene = new THREE.Scene();
scene.background = new THREE.Color('#182230');
scene.fog = new THREE.Fog('#182230', 22, 70);

const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 500);
camera.position.set(8, 7, 10);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
viewport.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.target.set(0, 0.8, 0);
controls.maxPolarAngle = Math.PI * 0.49;
controls.minDistance = 2;
controls.maxDistance = 50;

scene.add(new THREE.HemisphereLight(0xc6e2ff, 0x36404d, 2.0));
const sun = new THREE.DirectionalLight(0xffffff, 3.0);
sun.position.set(6, 12, 7);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -15; sun.shadow.camera.right = 15;
sun.shadow.camera.top = 15; sun.shadow.camera.bottom = -15;
scene.add(sun);

const grid = new THREE.GridHelper(40, 40, 0x6385a7, 0x34465c);
grid.position.y = 0.005;
scene.add(grid);
const axes = new THREE.AxesHelper(2.5);
axes.position.y = 0.02;
scene.add(axes);

const objects = [];
let selected = null;
let nextId = 1;
let playing = false;
let playSnapshot = null;

const fields = {
  name: document.getElementById('objectName'),
  type: document.getElementById('objectType'),
  posX: document.getElementById('posX'), posY: document.getElementById('posY'), posZ: document.getElementById('posZ'),
  rotX: document.getElementById('rotX'), rotY: document.getElementById('rotY'), rotZ: document.getElementById('rotZ'),
  scaleX: document.getElementById('scaleX'), scaleY: document.getElementById('scaleY'), scaleZ: document.getElementById('scaleZ'),
  color: document.getElementById('objectColor')
};

function setStatus(message) { statusMessage.textContent = message; }
function makeMaterial(color = '#43a5ff') {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.62, metalness: 0.08 });
}
function geometryFor(type) {
  if (type === 'sphere') return new THREE.SphereGeometry(0.65, 32, 20);
  if (type === 'cylinder') return new THREE.CylinderGeometry(0.55, 0.55, 1.3, 32);
  if (type === 'floor') return new THREE.BoxGeometry(8, 0.15, 8);
  return new THREE.BoxGeometry(1.2, 1.2, 1.2);
}
function addObject(type, options = {}) {
  if (playing) return;
  const defaults = { box: 'Cube', sphere: 'Sphere', cylinder: 'Cylinder', floor: 'Floor' };
  const mesh = new THREE.Mesh(geometryFor(type), makeMaterial(options.color || (type === 'floor' ? '#64748b' : '#43a5ff')));
  mesh.name = options.name || `${defaults[type] || 'Object'} ${nextId++}`;
  mesh.userData.editorType = type;
  mesh.castShadow = type !== 'floor';
  mesh.receiveShadow = true;
  if (options.position) mesh.position.fromArray(options.position);
  else if (type === 'floor') mesh.position.set(0, -0.12, 0);
  else mesh.position.set((Math.random() - 0.5) * 2, type === 'sphere' ? 0.7 : 0.65, (Math.random() - 0.5) * 2);
  if (options.rotation) mesh.rotation.set(...options.rotation);
  if (options.scale) mesh.scale.fromArray(options.scale);
  if (options.id) mesh.userData.objectId = options.id;
  else mesh.userData.objectId = `obj-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  scene.add(mesh);
  objects.push(mesh);
  refreshHierarchy();
  selectObject(mesh);
  setStatus(`${mesh.name} added.`);
  return mesh;
}
function refreshHierarchy() {
  hierarchy.innerHTML = '';
  objects.forEach(obj => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = `object-row${obj === selected ? ' selected' : ''}`;
    const icons = { box: '▧', sphere: '●', cylinder: '⬭', floor: '▤' };
    const icon = document.createElement('span');
    icon.className = 'object-icon';
    icon.textContent = icons[obj.userData.editorType] || '◇';
    const label = document.createElement('span');
    label.className = 'object-label';
    label.textContent = obj.name;
    row.append(icon, label);
    row.addEventListener('click', () => selectObject(obj));
    hierarchy.appendChild(row);
  });
  objectCount.textContent = String(objects.length);
}
function selectObject(obj) {
  selected = obj;
  refreshHierarchy();
  inspector.classList.toggle('hidden', !obj);
  inspectorEmpty.classList.toggle('hidden', !!obj);
  if (!obj) return;
  fields.name.value = obj.name;
  fields.type.value = obj.userData.editorType || 'Object';
  fields.posX.value = obj.position.x.toFixed(2);
  fields.posY.value = obj.position.y.toFixed(2);
  fields.posZ.value = obj.position.z.toFixed(2);
  fields.rotX.value = THREE.MathUtils.radToDeg(obj.rotation.x).toFixed(0);
  fields.rotY.value = THREE.MathUtils.radToDeg(obj.rotation.y).toFixed(0);
  fields.rotZ.value = THREE.MathUtils.radToDeg(obj.rotation.z).toFixed(0);
  fields.scaleX.value = obj.scale.x.toFixed(2);
  fields.scaleY.value = obj.scale.y.toFixed(2);
  fields.scaleZ.value = obj.scale.z.toFixed(2);
  fields.color.value = `#${obj.material.color.getHexString()}`;
}
function updateSelectedFromInspector() {
  if (!selected || playing) return;
  selected.name = fields.name.value.trim() || 'Object';
  selected.position.set(num(fields.posX, selected.position.x), num(fields.posY, selected.position.y), num(fields.posZ, selected.position.z));
  selected.rotation.set(
    THREE.MathUtils.degToRad(num(fields.rotX, 0)),
    THREE.MathUtils.degToRad(num(fields.rotY, 0)),
    THREE.MathUtils.degToRad(num(fields.rotZ, 0))
  );
  selected.scale.set(
    Math.max(0.1, num(fields.scaleX, 1)),
    Math.max(0.1, num(fields.scaleY, 1)),
    Math.max(0.1, num(fields.scaleZ, 1))
  );
  selected.material.color.set(fields.color.value);
  refreshHierarchy();
}
function num(input, fallback) {
  const parsed = Number.parseFloat(input.value);
  return Number.isFinite(parsed) ? parsed : fallback;
}
Object.values(fields).forEach(input => {
  if (input === fields.type) return;
  input.addEventListener('input', updateSelectedFromInspector);
});
document.querySelectorAll('[data-add]').forEach(button => {
  button.addEventListener('click', () => addObject(button.dataset.add));
});
document.getElementById('deleteBtn').addEventListener('click', () => {
  if (!selected || playing) return;
  const name = selected.name;
  scene.remove(selected);
  const idx = objects.indexOf(selected);
  if (idx >= 0) objects.splice(idx, 1);
  selected = null;
  selectObject(null);
  setStatus(`${name} deleted.`);
});
document.getElementById('duplicateBtn').addEventListener('click', () => {
  if (!selected || playing) return;
  const source = selected;
  addObject(source.userData.editorType, {
    name: `${source.name} Copy`,
    position: [source.position.x + 1.1, source.position.y, source.position.z],
    rotation: [source.rotation.x, source.rotation.y, source.rotation.z],
    scale: [source.scale.x, source.scale.y, source.scale.z],
    color: `#${source.material.color.getHexString()}`
  });
});
function serializeScene() {
  return {
    format: 'FreeForgeScene', version: 1,
    objects: objects.map(obj => ({
      id: obj.userData.objectId, name: obj.name, type: obj.userData.editorType,
      position: obj.position.toArray(), rotation: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
      scale: obj.scale.toArray(), color: `#${obj.material.color.getHexString()}`
    }))
  };
}
function saveProject() {
  const data = JSON.stringify(serializeScene(), null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'freeforge-project.json'; a.click();
  URL.revokeObjectURL(url);
  try { localStorage.setItem('freeforge-autosave', data); } catch (e) { /* local storage may be blocked */ }
  setStatus('Project downloaded and browser autosave attempted.');
}
document.getElementById('saveBtn').addEventListener('click', saveProject);
document.getElementById('loadBtn').addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', async () => {
  const file = fileInput.files && fileInput.files[0];
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!data || data.format !== 'FreeForgeScene' || !Array.isArray(data.objects)) throw new Error('Invalid FreeForge project file');
    clearObjects();
    data.objects.forEach(item => {
      if (!['box', 'sphere', 'cylinder', 'floor'].includes(item.type)) return;
      addObject(item.type, item);
    });
    if (!objects.length) selectObject(null);
    setStatus(`Loaded ${objects.length} object(s).`);
  } catch (error) {
    alert('Could not load this project. Please choose a FreeForge JSON file.');
  }
  fileInput.value = '';
});
function clearObjects() {
  objects.forEach(obj => scene.remove(obj));
  objects.length = 0;
  selected = null;
  refreshHierarchy();
  selectObject(null);
}
function setPlayMode(enable) {
  if (enable === playing) return;
  playing = enable;
  if (playing) {
    playSnapshot = serializeScene();
    document.getElementById('playBtn').disabled = true;
    document.getElementById('stopBtn').disabled = false;
    document.getElementById('playOverlay').classList.remove('hidden');
    sceneStatus.textContent = 'Playing';
    setStatus('Play preview running. Stop to return to editing.');
  } else {
    if (playSnapshot) {
      clearObjects();
      playSnapshot.objects.forEach(item => addObject(item.type, item));
      if (!objects.length) selectObject(null);
    }
    document.getElementById('playBtn').disabled = false;
    document.getElementById('stopBtn').disabled = true;
    document.getElementById('playOverlay').classList.add('hidden');
    sceneStatus.textContent = 'Ready';
    setStatus('Returned to editor.');
    playSnapshot = null;
  }
  document.querySelectorAll('[data-add], #deleteBtn, #duplicateBtn').forEach(el => el.disabled = playing);
}
document.getElementById('playBtn').addEventListener('click', () => setPlayMode(true));
document.getElementById('stopBtn').addEventListener('click', () => setPlayMode(false));
document.getElementById('overlayStopBtn').addEventListener('click', () => setPlayMode(false));

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
renderer.domElement.addEventListener('pointerdown', event => {
  if (playing) return;
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects(objects, false);
  if (hits.length) selectObject(hits[0].object);
});
function resizeRenderer() {
  const width = Math.max(1, viewport.clientWidth);
  const height = Math.max(1, viewport.clientHeight);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
}
const resizeObserver = new ResizeObserver(resizeRenderer);
resizeObserver.observe(viewport);
window.addEventListener('resize', resizeRenderer);
resizeRenderer();

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}
animate();

// Start with a simple floor and one cube so the editor isn't empty.
addObject('floor', { name: 'Ground', position: [0, -0.12, 0], color: '#65758b', scale: [1, 1, 1] });
addObject('box', { name: 'Starter Cube', position: [0, 0.72, 0], color: '#43a5ff' });
setStatus('Ready. Select objects in the viewport or World Outliner.');
